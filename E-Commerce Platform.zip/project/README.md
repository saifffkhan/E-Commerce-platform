# Weather Dashboard

A modern, responsive weather dashboard built with React, TypeScript, and Tailwind CSS. Get real-time weather information for any location worldwide using the OpenWeatherMap API.

![Weather Dashboard](https://images.unsplash.com/photo-1504608524841-42fe6f032b4b?auto=format&fit=crop&q=80&w=1200&h=400)

## Features

- 🌡️ Real-time weather data
- 🎨 Modern, responsive design
- 🔍 Search for any location
- 📱 Mobile-friendly interface
- ⚡ Fast and lightweight
- 🛡️ Type-safe with TypeScript
- 🚀 Built with Vite for optimal performance

## Tech Stack

- React 18
- TypeScript
- Tailwind CSS
- Vite
- Axios
- React Hot Toast
- Lucide React Icons

## Prerequisites

Before you begin, ensure you have:

- Node.js (v18 or higher)
- npm or yarn
- OpenWeatherMap API key ([Get one here](https://openweathermap.org/api))

## Getting Started

1. Clone the repository:
```bash
git clone https://github.com/yourusername/weather-dashboard.git
cd weather-dashboard
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file in the root directory and add your OpenWeatherMap API key:
```env
VITE_OPENWEATHER_API_KEY=your_api_key_here
```

4. Update the API key in `src/services/weatherService.ts`:
```typescript
const API_KEY = import.meta.env.VITE_OPENWEATHER_API_KEY;
```

5. Start the development server:
```bash
npm run dev
```

6. Open your browser and navigate to `http://localhost:5173`

## Usage

1. Enter a city name in the search bar
2. Press Enter or click the search icon
3. View detailed weather information including:
   - Current temperature
   - Weather description
   - Humidity levels
   - Wind speed
   - Weather icon

## Project Structure

```
weather-dashboard/
├── src/
│   ├── components/
│   │   ├── SearchBar.tsx
│   │   └── WeatherCard.tsx
│   ├── services/
│   │   └── weatherService.ts
│   ├── types/
│   │   └── weather.ts
│   ├── App.tsx
│   └── main.tsx
├── public/
├── package.json
├── tsconfig.json
└── README.md
```

## Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- [OpenWeatherMap API](https://openweathermap.org/api) for weather data
- [Lucide React](https://lucide.dev) for beautiful icons
- [Tailwind CSS](https://tailwindcss.com) for styling
- [React Hot Toast](https://react-hot-toast.com) for notifications

## Contact

Your Name - [@yourtwitter](https://twitter.com/yourtwitter)

Project Link: [https://github.com/yourusername/weather-dashboard](https://github.com/yourusername/weather-dashboard)