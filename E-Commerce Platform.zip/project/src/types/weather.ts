export interface WeatherData {
  location: string;
  temperature: number;
  description: string;
  humidity: number;
  windSpeed: number;
  icon: string;
}

export interface UserPreferences {
  favoriteLocations: string[];
  temperatureUnit: 'celsius' | 'fahrenheit';
}

export interface User {
  id: string;
  email: string;
  preferences: UserPreferences;
}