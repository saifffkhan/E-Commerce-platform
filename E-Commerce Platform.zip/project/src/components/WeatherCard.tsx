import React from 'react';
import { Cloud, Droplets, Wind } from 'lucide-react';
import { WeatherData } from '../types/weather';

interface WeatherCardProps {
  data: WeatherData;
}

export const WeatherCard: React.FC<WeatherCardProps> = ({ data }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-sm">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800">{data.location}</h2>
        <img src={data.icon} alt={data.description} className="w-16 h-16" />
      </div>
      
      <div className="text-4xl font-bold text-gray-900 mb-4">
        {Math.round(data.temperature)}°C
      </div>
      
      <p className="text-gray-600 capitalize mb-4">{data.description}</p>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="flex items-center">
          <Droplets className="w-5 h-5 text-blue-500 mr-2" />
          <span className="text-gray-700">{data.humidity}% Humidity</span>
        </div>
        <div className="flex items-center">
          <Wind className="w-5 h-5 text-blue-500 mr-2" />
          <span className="text-gray-700">{data.windSpeed} m/s</span>
        </div>
      </div>
    </div>
  );
};