import axios from 'axios';
import { WeatherData } from '../types/weather';

const API_KEY = 'YOUR_OPENWEATHERMAP_API_KEY'; // Replace with actual API key
const BASE_URL = 'https://api.openweathermap.org/data/2.5';

export const getWeatherData = async (location: string): Promise<WeatherData> => {
  try {
    const response = await axios.get(
      `${BASE_URL}/weather?q=${location}&appid=${API_KEY}&units=metric`
    );

    return {
      location: response.data.name,
      temperature: response.data.main.temp,
      description: response.data.weather[0].description,
      humidity: response.data.main.humidity,
      windSpeed: response.data.wind.speed,
      icon: `https://openweathermap.org/img/wn/${response.data.weather[0].icon}@2x.png`
    };
  } catch (error) {
    throw new Error('Failed to fetch weather data');
  }
};