import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3000/api',
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const auth = {
  login: async (email: string, password: string) => {
    const { data } = await api.post('/auth/login', { email, password });
    localStorage.setItem('token', data.token);
    return data;
  },
  register: async (email: string, password: string, name: string) => {
    const { data } = await api.post('/auth/register', { email, password, name });
    localStorage.setItem('token', data.token);
    return data;
  },
  logout: () => {
    localStorage.removeItem('token');
  },
};

export const products = {
  getAll: () => api.get('/products').then((res) => res.data),
  getById: (id: string) => api.get(`/products/${id}`).then((res) => res.data),
  create: (product: FormData) => api.post('/products', product).then((res) => res.data),
  update: (id: string, product: FormData) => api.put(`/products/${id}`, product).then((res) => res.data),
  delete: (id: string) => api.delete(`/products/${id}`).then((res) => res.data),
};

export const orders = {
  create: (order: any) => api.post('/orders', order).then((res) => res.data),
  getAll: () => api.get('/orders').then((res) => res.data),
  getById: (id: string) => api.get(`/orders/${id}`).then((res) => res.data),
  updateStatus: (id: string, status: string) => api.patch(`/orders/${id}/status`, { status }).then((res) => res.data),
};

export const stripe = {
  createPaymentIntent: (amount: number) =>
    api.post('/stripe/create-payment-intent', { amount }).then((res) => res.data),
};

export default api;